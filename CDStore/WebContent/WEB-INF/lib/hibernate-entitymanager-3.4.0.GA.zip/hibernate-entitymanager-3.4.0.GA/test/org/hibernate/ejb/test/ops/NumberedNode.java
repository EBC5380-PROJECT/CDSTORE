//$Id: NumberedNode.java 11282 2007-03-14 22:05:59Z epbernard $
package org.hibernate.ejb.test.ops;

/**
 * @author Gavin King
 */
public class NumberedNode extends Node {

	private long id;

	public NumberedNode() {
		super();
	}


	public NumberedNode(String name) {
		super( name );
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
}
