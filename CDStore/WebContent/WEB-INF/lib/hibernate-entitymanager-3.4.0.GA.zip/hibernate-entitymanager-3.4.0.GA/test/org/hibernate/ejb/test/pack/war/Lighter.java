//$Id: $
package org.hibernate.ejb.test.pack.war;

/**
 * @author Emmanuel Bernard
 */
public class Lighter {
	public String name;
	public String power;
}
