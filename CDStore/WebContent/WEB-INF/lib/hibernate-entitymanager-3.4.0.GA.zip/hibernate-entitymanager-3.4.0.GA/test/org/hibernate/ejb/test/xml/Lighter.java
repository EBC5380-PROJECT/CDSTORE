//$Id: $
package org.hibernate.ejb.test.xml;

/**
 * @author Emmanuel Bernard
 */
public class Lighter {
	public String name;
	public String power;
}
