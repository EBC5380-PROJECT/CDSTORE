//$Id: $
package org.hibernate.ejb.test.pack.defaultpar;

/**
 * @author Emmanuel Bernard
 */
public class Lighter {
	public String name;
	public String power;
}
