//$Id: $
package org.hibernate.ejb.test.xml;

/**
 * @author Emmanuel Bernard
 */
public class Light {
	public String name;
	public String power;
}
