@NamedQuery(name = "allMouse",
		query = "select m from ApplicationServer m") package org.hibernate.ejb.test.pack.defaultpar;

import org.hibernate.annotations.NamedQuery;

